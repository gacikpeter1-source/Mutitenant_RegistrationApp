# Setup Checklist

Use this checklist to ensure your Session Reservation System is properly configured.

## 📋 Pre-Deployment Checklist

### 1. Project Setup
- [ ] Node.js 18+ installed (`node -v`)
- [ ] npm or yarn installed
- [ ] Firebase account created
- [ ] Git installed (optional)

### 2. Dependencies
- [ ] Run `npm install`
- [ ] All dependencies installed successfully
- [ ] No vulnerability warnings (or resolved)

### 3. Firebase Configuration

#### Firebase Console
- [ ] Firebase project created
- [ ] Web app registered in project
- [ ] Firebase config values copied

#### Authentication
- [ ] Email/Password authentication enabled
- [ ] Authorized domains added (localhost, your-domain)

#### Firestore Database
- [ ] Database created (production mode)
- [ ] Security rules copied and published
- [ ] Test query works

#### Cloud Storage
- [ ] Storage bucket created
- [ ] Storage rules copied and published
- [ ] Test upload works

#### Cloud Functions
- [ ] Billing enabled (Blaze plan)
- [ ] Firebase CLI installed (`firebase --version`)
- [ ] Logged into Firebase CLI (`firebase login`)
- [ ] Functions initialized (`firebase init functions`)
- [ ] Functions deployed (`firebase deploy --only functions`)

### 4. Application Configuration
- [ ] `src/firebase/config.js` created from `config.example.js`
- [ ] Firebase credentials added to `config.js`
- [ ] `config.js` added to `.gitignore`
- [ ] Settings document created in Firestore

### 5. Initial Testing
- [ ] Dev server starts: `npm run dev`
- [ ] App loads at http://localhost:5173
- [ ] No console errors
- [ ] Can navigate to signup page
- [ ] Can create first owner account

### 6. Database Initialization
- [ ] Settings document exists in Firestore
- [ ] Theme colors configured
- [ ] First owner account created
- [ ] First organization created

### 7. Feature Testing

#### Authentication
- [ ] Can sign up new user
- [ ] Can log in
- [ ] Can log out
- [ ] Password reset works

#### Owner Functions
- [ ] Can create organization
- [ ] Can generate invite codes
- [ ] Can customize theme
- [ ] Can upload background image
- [ ] Can view all trainers

#### Trainer Functions
- [ ] Can sign up with invite code
- [ ] Can update profile
- [ ] Can upload profile picture
- [ ] Can create events
- [ ] Can view bookings

#### Public Functions
- [ ] Can view calendar without login
- [ ] Can see trainer list
- [ ] Can book session
- [ ] Can join waitlist
- [ ] Can cancel booking (with verification)
- [ ] QR code generation works

### 8. Production Readiness

#### Code Quality
- [ ] Build succeeds: `npm run build`
- [ ] No build warnings
- [ ] Lint passes: `npm run lint`

#### Security
- [ ] Firebase rules tested
- [ ] No sensitive data in code
- [ ] `config.js` not in Git
- [ ] Environment variables configured (if using)

#### Performance
- [ ] Images optimized
- [ ] Bundle size acceptable (<2MB)
- [ ] Page load under 3 seconds

### 9. Deployment

#### Git Repository
- [ ] Repository created on GitHub/GitLab
- [ ] Code pushed to repository
- [ ] `.gitignore` properly configured
- [ ] No sensitive files committed

#### Vercel Deployment
- [ ] Vercel account created
- [ ] Project imported to Vercel
- [ ] Build settings configured
- [ ] Environment variables added (if using)
- [ ] Deployed successfully
- [ ] Custom domain configured (optional)

#### Post-Deployment
- [ ] Production URL works
- [ ] HTTPS enabled
- [ ] Firebase authorized domains updated
- [ ] All features tested on production

### 10. Monitoring & Maintenance

#### Firebase Monitoring
- [ ] Budget alerts configured ($5, $10)
- [ ] Quota alerts enabled
- [ ] Usage dashboard checked

#### Error Tracking
- [ ] Console errors checked
- [ ] Firebase logs reviewed
- [ ] Function execution logs checked

#### Documentation
- [ ] Setup process documented
- [ ] Known issues documented
- [ ] Admin credentials secured

---

## 🎯 Quick Verification Commands

```bash
# Check Node.js version
node -v  # Should be 18+

# Check Firebase CLI
firebase --version

# Check if logged into Firebase
firebase projects:list

# Test build
npm run build

# Check for outdated packages
npm outdated

# Security audit
npm audit
```

---

## 🚨 Common Issues

### Can't run npm install
```bash
# Clear cache
npm cache clean --force
rm -rf node_modules package-lock.json
npm install
```

### Firebase connection fails
```bash
# Check config
cat src/firebase/config.js

# Test Firebase connection
firebase projects:list
```

### Build fails
```bash
# Check for errors
npm run build

# Check Node version
node -v  # Must be 18+
```

### Functions won't deploy
```bash
# Check billing
firebase open

# Check logs
firebase functions:log

# Deploy with debug
firebase deploy --only functions --debug
```

---

## ✅ Final Checklist Before Launch

- [ ] All features tested on production
- [ ] Mobile responsiveness verified
- [ ] Cross-browser testing done (Chrome, Firefox, Safari)
- [ ] Error handling works
- [ ] Email notifications working (if configured)
- [ ] Backup strategy in place
- [ ] Support contact information added
- [ ] Privacy policy added (if required)
- [ ] Terms of service added (if required)
- [ ] Analytics configured (optional)
- [ ] SEO metadata added (optional)

---

## 📞 Need Help?

If stuck on any step:
1. Check the detailed documentation in `/docs`
2. Review Firebase Console for errors
3. Check browser console for errors
4. Review function logs: `firebase functions:log`
5. Check GitHub issues (if template repository has one)

---

**Once all items are checked, you're ready to launch! 🚀**
