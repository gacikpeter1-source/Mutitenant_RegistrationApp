# Deployment Guide

Deploy your Session Reservation System to production using Vercel.

## 🚀 Deployment Options

1. **Vercel** (Recommended) - Easiest, free tier available
2. **Firebase Hosting** - Good if already using Firebase
3. **Netlify** - Alternative to Vercel
4. **Custom Server** - VPS, AWS, etc.

---

## Option 1: Vercel Deployment (Recommended)

### Why Vercel?
- ✅ Free tier (sufficient for most apps)
- ✅ Automatic HTTPS
- ✅ Global CDN
- ✅ Automatic deployments from Git
- ✅ Preview deployments for PRs
- ✅ Zero configuration needed

### Prerequisites
- GitHub/GitLab/Bitbucket account
- Vercel account (free)
- Firebase setup completed

---

### Step 1: Prepare Your Code

1. **Ensure `config.js` is in `.gitignore`:**

```
# Add to .gitignore
src/firebase/config.js
.env
.env.local
```

2. **Create `.env.example` file** (optional but recommended):

```bash
# .env.example
VITE_FIREBASE_API_KEY=your_api_key_here
VITE_FIREBASE_AUTH_DOMAIN=your-project.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=your-project-id
VITE_FIREBASE_STORAGE_BUCKET=your-project.appspot.com
VITE_FIREBASE_MESSAGING_SENDER_ID=123456789
VITE_FIREBASE_APP_ID=1:123456789:web:abc123
```

3. **Update `firebase/config.js` to use environment variables** (optional):

```javascript
export const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || "fallback_key",
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID
};
```

---

### Step 2: Push to GitHub

```bash
# Initialize git (if not already done)
git init

# Add all files
git add .

# Commit
git commit -m "Initial commit"

# Create repository on GitHub, then:
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git branch -M main
git push -u origin main
```

---

### Step 3: Deploy to Vercel

#### Method A: Vercel Dashboard (Easiest)

1. Go to [vercel.com](https://vercel.com)
2. Click **"Add New..."** → **"Project"**
3. **Import** your GitHub repository
4. Vercel will auto-detect Vite settings:
   - **Build Command:** `npm run build`
   - **Output Directory:** `dist`
   - **Install Command:** `npm install`
5. Click **"Deploy"**
6. Wait 1-2 minutes for deployment

#### Method B: Vercel CLI

```bash
# Install Vercel CLI
npm install -g vercel

# Login
vercel login

# Deploy
vercel

# Follow prompts:
# - Set up and deploy? Yes
# - Which scope? Your account
# - Link to existing project? No
# - Project name? your-project-name
# - Directory? ./
# - Override settings? No

# Production deployment
vercel --prod
```

---

### Step 4: Add Environment Variables (If Using)

1. In Vercel Dashboard, go to your project
2. Click **"Settings"** → **"Environment Variables"**
3. Add each variable:
   - `VITE_FIREBASE_API_KEY`
   - `VITE_FIREBASE_AUTH_DOMAIN`
   - `VITE_FIREBASE_PROJECT_ID`
   - `VITE_FIREBASE_STORAGE_BUCKET`
   - `VITE_FIREBASE_MESSAGING_SENDER_ID`
   - `VITE_FIREBASE_APP_ID`
4. Set for: **Production**, **Preview**, and **Development**
5. Click **"Save"**
6. **Redeploy** for changes to take effect

---

### Step 5: Configure Custom Domain (Optional)

1. Go to **"Settings"** → **"Domains"**
2. Click **"Add"**
3. Enter your domain (e.g., `myapp.com`)
4. Follow DNS configuration instructions
5. Wait for DNS propagation (up to 48 hours)

---

### Step 6: Update Firebase Authorized Domains

1. Go to Firebase Console → **Authentication** → **Settings**
2. Scroll to **"Authorized domains"**
3. Click **"Add domain"**
4. Add your Vercel domain:
   - `your-project.vercel.app`
   - Your custom domain (if using)
5. Click **"Add"**

---

### Step 7: Test Deployment

1. Visit your Vercel URL
2. Test key features:
   - [ ] Sign up / Login works
   - [ ] Calendar loads
   - [ ] Can create organization
   - [ ] Can view trainers
   - [ ] Public booking works
   - [ ] Background image appears (if set)
3. Check browser console for errors
4. Test on mobile device

---

## Option 2: Firebase Hosting

### Step 1: Install Firebase Tools

```bash
npm install -g firebase-tools
```

### Step 2: Login and Initialize

```bash
firebase login
firebase init hosting

# Select options:
# - Use existing project
# - Public directory: dist
# - Single-page app: Yes
# - Set up automatic builds: No
# - Overwrite index.html: No
```

### Step 3: Build and Deploy

```bash
# Build for production
npm run build

# Deploy
firebase deploy --only hosting
```

Your app will be live at: `https://your-project-id.web.app`

---

## Option 3: Netlify

### Via Dashboard

1. Go to [netlify.com](https://netlify.com)
2. Click **"Add new site"** → **"Import an existing project"**
3. Connect to your Git provider
4. Select repository
5. Configure:
   - **Build command:** `npm run build`
   - **Publish directory:** `dist`
6. Click **"Deploy"**

### Via CLI

```bash
npm install -g netlify-cli
netlify login
netlify deploy --prod
```

---

## 🔒 Security Checklist

Before going live:

- [ ] Firebase security rules tested
- [ ] `config.js` not in Git repository
- [ ] Environment variables set (if using)
- [ ] HTTPS enabled (automatic with Vercel/Netlify)
- [ ] Custom domain configured with SSL
- [ ] Firebase authorized domains updated
- [ ] Budget alerts set up in Firebase
- [ ] Error monitoring configured (optional)

---

## 📊 Post-Deployment Monitoring

### Vercel Analytics (Free)

1. Go to your project → **"Analytics"**
2. Enable Web Analytics
3. View page views, performance metrics

### Firebase Monitoring

1. **Authentication** - Track user signups
2. **Firestore** - Monitor database usage
3. **Functions** - Check function invocations
4. **Storage** - Track file uploads

---

## 🔄 Continuous Deployment

### Automatic Deployments

With Vercel/Netlify:
1. Push to `main` branch → Auto-deploy to production
2. Push to any branch → Auto-create preview deployment
3. Pull requests get unique preview URLs

### Manual Deployments

```bash
# Vercel
vercel --prod

# Firebase
npm run build && firebase deploy --only hosting

# Netlify
netlify deploy --prod
```

---

## 🐛 Common Issues

### Build Fails

**Error:** "Module not found"
```bash
# Solution: Clear cache and reinstall
rm -rf node_modules package-lock.json
npm install
npm run build
```

### Firebase Connection Error

**Error:** "Firebase: Error (auth/unauthorized-domain)"
```
Solution: Add your Vercel domain to Firebase authorized domains
```

### Environment Variables Not Working

```
Solution:
1. Ensure variables start with VITE_
2. Redeploy after adding variables
3. Check variable names match exactly
```

### 404 on Refresh

**Problem:** SPA routes return 404 on direct access

**Solution for Vercel:**
Create `vercel.json`:
```json
{
  "rewrites": [
    { "source": "/(.*)", "destination": "/index.html" }
  ]
}
```

**Solution for Netlify:**
Create `public/_redirects`:
```
/*  /index.html  200
```

---

## 📈 Performance Optimization

### Build Optimization

```bash
# Analyze bundle size
npm run build -- --mode production

# Check output in dist/ folder
```

### Vercel Settings

1. **Edge Functions** - Enable for faster response
2. **Image Optimization** - Automatic with Vercel
3. **Caching** - Configured automatically

---

## 💰 Cost Estimation

### Vercel Free Tier
- ✅ 100 GB bandwidth/month
- ✅ 100 deployments/day
- ✅ Unlimited sites
- **Cost:** $0/month (sufficient for most small apps)

### Firebase Free Tier (Spark Plan)
- ✅ 10 GB storage
- ✅ 50K reads/day
- ✅ 20K writes/day
- **Cost:** $0/month

### Firebase Blaze Plan (With Cloud Functions)
- Pay-as-you-go
- Typical cost for small app: $1-5/month
- 2M function invocations/month free

---

## 📞 Support

### Vercel
- [Documentation](https://vercel.com/docs)
- [Community](https://vercel.com/community)

### Firebase
- [Documentation](https://firebase.google.com/docs)
- [Support](https://firebase.google.com/support)

---

**🎉 Congratulations! Your app is now live!**

Next: Share your URL and start inviting trainers!
