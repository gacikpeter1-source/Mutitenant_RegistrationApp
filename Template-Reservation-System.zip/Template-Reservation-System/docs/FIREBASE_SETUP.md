# Firebase Setup Guide

Complete step-by-step guide to set up Firebase for your Session Reservation System.

## 📋 Overview

You'll need to set up:
1. Firebase Project
2. Authentication
3. Firestore Database
4. Cloud Storage
5. Cloud Functions
6. Security Rules

**Time Required:** 15-20 minutes

---

## Step 1: Create Firebase Project

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Click **"Add project"**
3. Enter project name (e.g., "my-reservation-system")
4. **Disable Google Analytics** (optional, not needed)
5. Click **"Create project"**
6. Wait for project creation to complete

---

## Step 2: Register Web App

1. In Firebase Console, click the **Web icon** (`</>`)
2. Enter app nickname (e.g., "Reservation Web App")
3. **Don't check** "Set up Firebase Hosting" (we'll use Vercel)
4. Click **"Register app"**
5. **IMPORTANT:** Copy the `firebaseConfig` object - you'll need this!

```javascript
// This is what you'll copy
const firebaseConfig = {
  apiKey: "AIza...",
  authDomain: "your-project.firebaseapp.com",
  projectId: "your-project-id",
  storageBucket: "your-project.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abc123"
};
```

6. Save this config - you'll add it to `src/firebase/config.js` later
7. Click **"Continue to console"**

---

## Step 3: Enable Authentication

### 3.1 Enable Email/Password

1. In left sidebar, click **"Authentication"**
2. Click **"Get started"**
3. Click **"Sign-in method"** tab
4. Click **"Email/Password"**
5. Toggle **"Enable"** ON
6. **Leave "Email link" disabled**
7. Click **"Save"**

### 3.2 Add Authorized Domains

1. Go to **"Settings"** tab in Authentication
2. Scroll to **"Authorized domains"**
3. Add your domains:
   - `localhost` (already there)
   - Your Vercel domain (e.g., `my-app.vercel.app`)
   - Your custom domain (if any)

---

## Step 4: Set Up Firestore Database

### 4.1 Create Database

1. In left sidebar, click **"Firestore Database"**
2. Click **"Create database"**
3. Select **"Start in production mode"** (we'll add rules next)
4. Choose location (select closest to your users)
5. Click **"Enable"**

### 4.2 Add Firestore Security Rules

1. Click **"Rules"** tab
2. **Replace all content** with this:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    // Helper functions
    function isOwner() {
      return request.auth != null && 
             exists(/databases/$(database)/documents/owners/$(request.auth.uid));
    }
    
    function isTrainer() {
      return request.auth != null && 
             exists(/databases/$(database)/documents/trainers/$(request.auth.uid));
    }
    
    function isOwnerOrTrainer() {
      return isOwner() || isTrainer();
    }
    
    // Owners collection
    match /owners/{ownerId} {
      allow read: if request.auth != null && request.auth.uid == ownerId;
      allow create: if request.auth != null && request.auth.uid == ownerId;
      allow update: if request.auth != null && request.auth.uid == ownerId;
      allow delete: if false;
    }
    
    // Trainers collection
    match /trainers/{trainerId} {
      allow read: if true;
      allow create: if request.auth != null && request.auth.uid == trainerId;
      allow update: if request.auth != null && 
                     (request.auth.uid == trainerId || isOwner());
      allow delete: if isOwner();
    }
    
    // Organizations collection
    match /organizations/{orgId} {
      allow read: if true;
      allow write: if isOwner();
    }
    
    // Events collection
    match /events/{eventId} {
      allow read: if true;
      allow create: if isOwnerOrTrainer();
      allow update: if isOwnerOrTrainer();
      allow delete: if isOwnerOrTrainer();
    }
    
    // Bookings collection
    match /bookings/{bookingId} {
      allow read: if true;
      allow create: if true;
      allow delete: if isOwnerOrTrainer();
    }
    
    // Waitlists collection
    match /waitlists/{waitlistId} {
      allow read: if true;
      allow create: if true;
      allow delete: if isOwnerOrTrainer();
    }
    
    // Invite codes collection
    match /inviteCodes/{codeId} {
      allow read: if true;
      allow create: if isOwner();
      allow update: if true;
      allow delete: if isOwner();
    }
    
    // Settings collection
    match /settings/{settingId} {
      allow read: if true;
      allow write: if isOwner();
    }
  }
}
```

3. Click **"Publish"**

---

## Step 5: Set Up Cloud Storage

### 5.1 Create Storage Bucket

1. In left sidebar, click **"Storage"**
2. Click **"Get started"**
3. Choose **"Start in production mode"**
4. Use default location (same as Firestore)
5. Click **"Done"**

### 5.2 Add Storage Security Rules

1. Click **"Rules"** tab
2. **Replace all content** with this:

```javascript
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    
    // Organization logos
    match /organizations/{orgId}/{fileName} {
      allow read: if true;
      allow write: if request.auth != null;
    }
    
    // Trainer profiles
    match /trainers/{userId}/{fileName} {
      allow read: if true;
      allow write: if request.auth != null && request.auth.uid == userId;
    }
    
    // Background images
    match /backgrounds/{fileName} {
      allow read: if true;
      allow write: if request.auth != null;
    }
  }
}
```

3. Click **"Publish"**

---

## Step 6: Set Up Cloud Functions

### 6.1 Enable Billing (Required for Cloud Functions)

1. In Firebase Console, click **⚙️ Settings icon** → **"Usage and billing"**
2. Click **"Modify plan"**
3. Select **"Blaze (Pay as you go)"**
   - **Don't worry!** Free tier includes:
   - 2M function invocations/month
   - 400,000 GB-seconds/month
   - Most small apps stay free
4. Add payment method
5. Set budget alerts (recommended: $5/month alert)

### 6.2 Install Firebase CLI

```bash
npm install -g firebase-tools
```

### 6.3 Login to Firebase

```bash
firebase login
```

### 6.4 Initialize Functions in Your Project

```bash
# Navigate to your project folder
cd Template-Reservation-System

# Initialize Firebase
firebase init functions

# Answer prompts:
# - Use existing project: YES
# - Select your project
# - Language: JavaScript
# - ESLint: Yes
# - Install dependencies: Yes
```

### 6.5 Replace Functions Code

The `functions/index.js` file is already included in the template. It contains:

- **cancelBooking** - Allows users to cancel bookings with email/phone verification
- Auto-promotion from waitlist
- Email notifications

### 6.6 Deploy Cloud Functions

```bash
# Deploy all functions
firebase deploy --only functions

# Or deploy specific function
firebase deploy --only functions:cancelBooking
```

---

## Step 7: Configure Your App

### 7.1 Create Firebase Config File

1. Copy `src/firebase/config.example.js` to `src/firebase/config.js`
2. Paste your Firebase config from Step 2:

```javascript
// src/firebase/config.js
import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';
import { getFunctions } from 'firebase/functions';

export const firebaseConfig = {
  apiKey: "YOUR_API_KEY_HERE",
  authDomain: "your-project.firebaseapp.com",
  projectId: "your-project-id",
  storageBucket: "your-project.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abc123"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize services
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
export const functions = getFunctions(app);
```

3. **IMPORTANT:** Add `config.js` to `.gitignore`:

```
# Firebase config (keep private)
src/firebase/config.js
```

---

## Step 8: Initialize Settings Document

After deployment, create the initial settings document:

1. Go to **Firestore Database** in Firebase Console
2. Click **"Start collection"**
3. Collection ID: `settings`
4. Document ID: `app`
5. Add fields:

```
theme (map)
  ├─ primaryColor (string): "#FDB913"
  ├─ secondaryColor (string): "#F39C12"
  ├─ accentColor (string): "#FFD700"
  ├─ backgroundImage (string): null
  └─ backgroundOverlay (string): "rgba(13, 13, 13, 0.75)"
```

---

## ✅ Verification Checklist

Before going live, verify:

- [ ] Firebase config added to `src/firebase/config.js`
- [ ] Authentication enabled (Email/Password)
- [ ] Firestore rules published
- [ ] Storage rules published
- [ ] Cloud Functions deployed
- [ ] Settings document created
- [ ] Billing enabled (for Cloud Functions)
- [ ] Authorized domains added
- [ ] App builds successfully: `npm run build`
- [ ] Dev server works: `npm run dev`

---

## 🔐 Security Best Practices

1. **Never commit** `firebase/config.js` to Git
2. **Enable App Check** for production (optional but recommended)
3. **Set up budget alerts** in Firebase billing
4. **Review security rules** regularly
5. **Use environment variables** for sensitive data

---

## 📊 Monitoring

### Firebase Console Monitoring

1. **Authentication** → See user signups
2. **Firestore** → View database activity
3. **Storage** → Monitor file uploads
4. **Functions** → Check function executions and logs

### Set Up Alerts

1. Go to **⚙️ Settings** → **"Usage and billing"**
2. Set up:
   - Budget alerts ($5, $10 thresholds)
   - Quota alerts (80% usage warnings)

---

## 🆘 Troubleshooting

### "Firebase: Error (auth/operation-not-allowed)"
- Enable Email/Password authentication in Firebase Console

### "Missing or insufficient permissions"
- Check Firestore security rules are published
- Verify user is authenticated
- Check owner/trainer documents exist

### "Functions deployment failed"
- Ensure billing is enabled
- Check Node.js version in functions/package.json
- Run `firebase deploy --only functions --debug` for details

### "Storage upload failed (403)"
- Check Storage rules are published
- Verify user is authenticated
- Check file path matches rules

---

## 📞 Need Help?

- [Firebase Documentation](https://firebase.google.com/docs)
- [Firebase Support](https://firebase.google.com/support)
- Check logs: `firebase functions:log`

---

**Next:** See [DEPLOYMENT.md](./DEPLOYMENT.md) for deploying to Vercel!
