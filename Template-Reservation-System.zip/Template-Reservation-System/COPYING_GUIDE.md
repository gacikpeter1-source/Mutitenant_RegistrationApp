# Copying Files from Arena Sršňov Project

This guide explains which files to copy from your current Arena Sršňov project to complete the template.

## 📂 Current Project Location
`C:\Users\kicka\Documents\MyApps\Arena Srsnov`

## 📂 Template Location
`Template-Reservation-System` (this folder)

---

## 🔄 Files to Copy

### ✅ COPY THESE FOLDERS/FILES

#### 1. Source Code (`src/` folder)
Copy the entire `src/` folder, then clean it:

```
FROM: Arena Srsnov/src/
TO:   Template-Reservation-System/src/

THEN CLEAN:
- Remove src/firebase/config.js (keep config.example.js only)
- Check components for Arena Sršňov branding
- Remove any test data
```

#### 2. Functions (`functions/` folder)
```
FROM: Arena Srsnov/functions/
TO:   Template-Reservation-System/functions/

KEEP:
- index.js (Cloud Functions)
- package.json (dependencies)
```

#### 3. Public Assets (`public/` folder)
```
FROM: Arena Srsnov/public/
TO:   Template-Reservation-System/public/

THEN CLEAN:
- Remove Arena Sršňov logo
- Remove specific branding images
- Keep: favicon.ico, robots.txt, etc.
```

#### 4. Root Configuration Files
```
COPY THESE:
- index.html
- vite.config.js
- .eslintrc.cjs (if exists)
```

---

## ❌ DO NOT COPY THESE

### Sensitive/Project-Specific Files
- ❌ `src/firebase/config.js` - Contains your credentials!
- ❌ `.env` - Environment variables
- ❌ `.env.local`
- ❌ `.firebase/` - Firebase cache
- ❌ `.firebaserc` - Firebase project link
- ❌ `firebase.json` - Project-specific config
- ❌ `.git/` - Git history
- ❌ `.vercel/` - Vercel config
- ❌ `node_modules/` - Dependencies (will reinstall)
- ❌ `dist/` - Build output
- ❌ `package-lock.json` - Will regenerate

### Arena Sršňov Specific Assets
- ❌ Arena Sršňov logo files
- ❌ Arena Sršňov background images
- ❌ Organization-specific branding

---

## 🧹 Cleaning Steps After Copying

### 1. Remove Branding from Code

**Files to check:**
- `src/components/Navbar.jsx` - Remove organization name
- `src/pages/LandingPage.jsx` - Remove specific text/images
- `index.html` - Update title from "Arena Sršňov"

**Find and Replace:**
- "Arena Sršňov" → "Session Reservation"
- "Aréna Sršňov" → "Training Center"
- "ARÉNA SRŠŇOV" → "TRAINING CENTER"

### 2. Reset Theme to Default

**In `src/contexts/ThemeContext.jsx`:**
```javascript
const defaultTheme = {
  primaryColor: '#FDB913',      // Keep gold
  secondaryColor: '#F39C12',    // Keep dark gold
  accentColor: '#FFD700',       // Keep bright gold
  backgroundImage: null,         // Remove Arena Sršňov image
  backgroundOverlay: 'rgba(13, 13, 13, 0.75)'
};
```

### 3. Remove Test Data

**Check these files for hardcoded data:**
- Organization IDs
- Trainer IDs
- Event IDs
- Test user emails

### 4. Clean Firebase References

**In any file with Firebase calls, ensure:**
- No hardcoded organization: "u8K2yp9Zxu2Ov8T5c5Pb"
- No hardcoded test emails
- No specific trainer references

---

## 📝 Step-by-Step Copy Process

### Step 1: Create Base Structure
```bash
# The template folder already has:
- README.md
- docs/
- demo-data.json
- package.json
- .gitignore
```

### Step 2: Copy Source Files
```bash
# Copy entire src/ folder
cp -r "C:/Users/kicka/Documents/MyApps/Arena Srsnov/src" ./Template-Reservation-System/

# Remove config.js (keep example only)
rm ./Template-Reservation-System/src/firebase/config.js
```

### Step 3: Copy Functions
```bash
cp -r "C:/Users/kicka/Documents/MyApps/Arena Srsnov/functions" ./Template-Reservation-System/
```

### Step 4: Copy Public Assets
```bash
cp -r "C:/Users/kicka/Documents/MyApps/Arena Srsnov/public" ./Template-Reservation-System/

# Remove branding
rm ./Template-Reservation-System/public/*logo*.png
rm ./Template-Reservation-System/public/*srsnov*.* 
```

### Step 5: Copy Root Files
```bash
cp "C:/Users/kicka/Documents/MyApps/Arena Srsnov/index.html" ./Template-Reservation-System/
cp "C:/Users/kicka/Documents/MyApps/Arena Srsnov/vite.config.js" ./Template-Reservation-System/
```

### Step 6: Clean Branding
```bash
# Use find and replace in your editor:
# Find: "Arena Sršňov" or "Aréna Sršňov"
# Replace with: "Session Reservation System"
```

---

## 🔍 Verification Checklist

After copying, verify:

### File Structure
- [ ] `src/` folder exists with all components
- [ ] `src/firebase/config.example.js` exists (NOT config.js)
- [ ] `functions/` folder exists
- [ ] `public/` folder exists (no Arena Sršňov logos)
- [ ] `index.html` exists
- [ ] `vite.config.js` exists
- [ ] `package.json` exists (template version)
- [ ] `.gitignore` exists

### No Sensitive Data
- [ ] No `config.js` with real credentials
- [ ] No `.env` files
- [ ] No `.firebase/` folder
- [ ] No `.git/` folder
- [ ] No organization-specific data

### No Branding
- [ ] Search for "Sršňov" - should find 0 results
- [ ] Search for "Arena" - should find 0 results (except in docs)
- [ ] Check `index.html` title
- [ ] Check Navbar component
- [ ] Check LandingPage component

### Dependencies
- [ ] Run `npm install` - should work
- [ ] Run `npm run dev` - should start (will error without Firebase config, that's OK)
- [ ] Run `npm run build` - should build

---

## 🎨 Customizing for New User

The new user should:

### 1. Replace Placeholder Config
```bash
# Copy example to config
cp src/firebase/config.example.js src/firebase/config.js

# Add their Firebase credentials
# Edit src/firebase/config.js with their values
```

### 2. Customize Branding
- Update colors in Theme Settings
- Upload their logo
- Upload their background image
- Update app title in `index.html`

### 3. Set Up Their Firebase
- Follow `docs/FIREBASE_SETUP.md`
- Create their project
- Deploy their functions
- Add their rules

---

## ⚠️ Important Notes

### What Gets Preserved
✅ All functionality
✅ Color scheme (gold/yellow theme)
✅ Component structure
✅ Database schema
✅ Security rules patterns

### What Gets Removed
❌ Arena Sršňov branding
❌ Your Firebase credentials
❌ Test organizations
❌ Sample trainer data
❌ Background images

### What's Neutral
🟡 Code comments (review and clean if needed)
🟡 Variable names (functional, not branded)
🟡 Component names (generic)

---

## 🚀 After Copying

1. **Test the Template:**
   ```bash
   cd Template-Reservation-System
   npm install
   # Add placeholder Firebase config
   npm run dev
   ```

2. **Create ZIP Archive:**
   ```bash
   # Exclude node_modules and build files
   zip -r Template-Reservation-System.zip Template-Reservation-System/ -x "*/node_modules/*" "*/dist/*" "*/.git/*"
   ```

3. **Share the Template:**
   - Upload to GitHub as public repo
   - Share ZIP file
   - Include all documentation

---

## 📞 Questions?

If unsure about any file:
- **When in doubt, copy it** (we'll clean later)
- **Sensitive data? DON'T copy it**
- **Branding? Remove it**

**Template should work out-of-the-box with just Firebase setup!**
