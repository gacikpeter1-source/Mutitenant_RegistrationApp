# Session Reservation System - Template

A modern, responsive web application for managing training sessions, bookings, and trainer schedules. Built with React, Firebase, and Vite.

## 🎯 Features

- **Multi-Organization Support** - Manage multiple organizations with separate trainers and schedules
- **Trainer Management** - Approve trainers, manage profiles, and track availability
- **Event Scheduling** - Create recurring or one-time training sessions
- **Public Booking** - Allow users to book sessions without authentication
- **Waitlist System** - Automatic promotion when spots become available
- **QR Code Generation** - Generate printable QR codes for easy access
- **Theme Customization** - Customize colors and background images
- **Mobile Responsive** - Works seamlessly on all devices

## 📋 Prerequisites

Before you begin, ensure you have:

- Node.js 18+ installed
- A Firebase account (free tier is sufficient)
- A Vercel account (optional, for deployment)
- Git installed

## 🚀 Quick Start

### 1. Clone or Download Template

```bash
# If using git
git init
git add .
git commit -m "Initial commit"

# Or just download and extract the folder
```

### 2. Install Dependencies

```bash
npm install
```

### 3. Firebase Setup

Follow the detailed guide in [FIREBASE_SETUP.md](./FIREBASE_SETUP.md) to:
- Create a new Firebase project
- Set up Authentication
- Configure Firestore Database
- Set up Storage
- Deploy Cloud Functions
- Copy security rules

### 4. Configure Firebase

Copy `src/firebase/config.example.js` to `src/firebase/config.js` and add your credentials:

```javascript
export const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};
```

### 5. Run Development Server

```bash
npm run dev
```

Open [http://localhost:5173](http://localhost:5173) in your browser.

### 6. Create First Owner Account

1. Go to `/signup`
2. Create account with your email
3. You'll automatically be the first owner

## 📦 Project Structure

```
Template-Reservation-System/
├── src/
│   ├── components/          # React components
│   │   ├── auth/           # Authentication components
│   │   ├── booking/        # Booking system
│   │   ├── calendar/       # Calendar views
│   │   ├── modals/         # Modal dialogs
│   │   └── trainer/        # Trainer management
│   ├── contexts/           # React contexts
│   │   ├── AuthContext.jsx
│   │   ├── OrganizationContext.jsx
│   │   └── ThemeContext.jsx
│   ├── firebase/           # Firebase configuration
│   │   ├── auth.js         # Authentication functions
│   │   ├── config.js       # Firebase config (you create this)
│   │   ├── firestore.js    # Firestore functions
│   │   └── storage.js      # Storage functions
│   ├── pages/              # Page components
│   │   ├── owner/          # Owner dashboard pages
│   │   ├── trainer/        # Trainer pages
│   │   └── public/         # Public pages
│   └── App.jsx             # Main app component
├── functions/              # Cloud Functions
│   └── index.js           # Booking cancellation function
├── docs/                   # Documentation
│   ├── FIREBASE_SETUP.md  # Detailed Firebase guide
│   └── DEPLOYMENT.md      # Deployment instructions
└── package.json           # Dependencies

```

## 🎨 Default Theme

The template comes with a professional dark theme using yellow/gold accents:

- **Primary Color:** `#FDB913` (Gold)
- **Secondary Color:** `#F39C12` (Dark Gold)
- **Accent Color:** `#FFD700` (Bright Gold)
- **Background:** Dark with customizable image

You can change colors in **Settings → Theme Settings** after deployment.

## 🔐 User Roles

### Owner
- Full system access
- Create organizations
- Invite trainers
- Customize theme
- Manage all events

### Trainer
- Manage own profile
- Create and edit own events
- View bookings and waitlist
- Cannot access other trainers' data

### Public User (No Auth)
- View calendar
- Book available sessions
- Cancel bookings (with email/phone verification)
- Join waitlist

## 📱 Key Pages

- `/` - Landing page
- `/org/:orgId/calendar` - Public calendar view
- `/org/:orgId/trainers` - Trainer list
- `/dashboard` - Owner dashboard
- `/trainer-dashboard` - Trainer dashboard
- `/settings` - Owner settings
- `/qr-download` - QR code generator

## 🛠️ Available Scripts

```bash
npm run dev          # Start development server
npm run build        # Build for production
npm run preview      # Preview production build
npm run lint         # Run ESLint
```

## 🚀 Deployment

### Vercel (Recommended)

1. Push code to GitHub
2. Go to [vercel.com](https://vercel.com)
3. Import your repository
4. Set environment variables (if any)
5. Deploy!

See [DEPLOYMENT.md](./docs/DEPLOYMENT.md) for detailed instructions.

### Firebase Hosting

```bash
npm run build
firebase deploy --only hosting
```

## 📊 Adding Demo Data (Optional)

See `demo-data.json` for sample data structure. You can:

1. Manually add via Firebase Console
2. Use Firestore import tool
3. Create via the UI after deployment

## 🐛 Troubleshooting

### Firebase Connection Issues
- Verify `firebase/config.js` has correct credentials
- Check Firebase Console for enabled services
- Ensure billing is enabled for Cloud Functions

### Build Errors
- Clear node_modules: `rm -rf node_modules && npm install`
- Clear cache: `rm -rf .vite`
- Check Node.js version: `node -v` (should be 18+)

### Authentication Issues
- Enable Email/Password auth in Firebase Console
- Check Firebase Auth settings
- Verify domain is added to authorized domains

## 📚 Documentation

- [Firebase Setup Guide](./docs/FIREBASE_SETUP.md) - Detailed Firebase configuration
- [Deployment Guide](./docs/DEPLOYMENT.md) - Deploy to production
- [API Reference](./docs/API.md) - Firebase functions reference

## 🤝 Contributing

This is a template - feel free to customize for your needs!

## 📄 License

MIT License - feel free to use for personal or commercial projects.

## 🆘 Support

For issues or questions:
1. Check documentation in `/docs` folder
2. Review Firebase logs
3. Check browser console for errors

## 🎯 Next Steps After Setup

1. **Customize branding** - Update colors, logo, favicon
2. **Add organizations** - Create your first organization
3. **Invite trainers** - Generate invite codes
4. **Create events** - Set up training schedule
5. **Test booking flow** - Try public booking process
6. **Generate QR codes** - Create printable access codes
7. **Deploy to production** - Push to Vercel/Firebase

---

**Built with ❤️ using React + Firebase + Vite**
